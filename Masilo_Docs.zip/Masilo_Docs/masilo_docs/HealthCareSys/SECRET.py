SECRET_KEY = 'secret_key'
DEBUG = True
EMAIL = "your_email_goes_here"
PASSWORD = "password_in_plaintext_lol"