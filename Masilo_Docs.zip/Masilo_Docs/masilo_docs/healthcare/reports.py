from reports.base import ModelReport

class MyReport(ModelReport)
    name = "Report - My Report"