$('#id_username').attr('placeholder', 'Username');
$('#id_password').attr('placeholder', 'Password');
